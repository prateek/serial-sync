BEGIN TRANSACTION;
CREATE TABLE artifacts (
  id TEXT PRIMARY KEY,
  release_id TEXT NOT NULL,
  track_id TEXT NOT NULL,
  artifact_kind TEXT NOT NULL,
  is_canonical INTEGER NOT NULL,
  filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  storage_ref TEXT NOT NULL,
  built_at TEXT NOT NULL,
  state TEXT NOT NULL,
  metadata_ref TEXT NOT NULL,
  normalized_ref TEXT NOT NULL,
  raw_ref TEXT NOT NULL,
  UNIQUE(release_id, sha256, artifact_kind)
);
INSERT INTO "artifacts" VALUES('art_76477aad-0a1b-441a-99b6-88141eabc630','rel_aefdb067-45a9-48f8-819c-5dab0b05f2e6','trk_10798eed-e63a-4df7-aa86-da104e9e430a','epub',1,'nightmare-ch00017-r154807035.epub','application/epub+zip','403d22a62875d62fe63a84848a0f26775e44c67d23030919fca6c6a28fb6c463','@ROOT@/artifacts/actus/nightmare/154807035/nightmare-ch00017-r154807035.epub','2026-09-20T02:44:13.459815558Z','materialized','@ROOT@/artifacts/actus/nightmare/154807035/nightmare-ch00017-r154807035.epub.metadata.json','@ROOT@/artifacts/actus/nightmare/154807035/nightmare-ch00017-r154807035.epub.normalized.json','@ROOT@/artifacts/actus/nightmare/154807035/nightmare-ch00017-r154807035.epub.raw.json');
INSERT INTO "artifacts" VALUES('art_0ba37171-60a2-4b43-8ea1-efb155a9c437','rel_2034feca-b809-4267-8a30-38756c8723a7','trk_10798eed-e63a-4df7-aa86-da104e9e430a','epub',1,'nightmare-ch00042-r154807100.epub','application/epub+zip','923b9ee8ce8a2fc9ca51d9f3bf9f4b8dc7f3b38bd20dc7907a9b70e820e072ac','@ROOT@/artifacts/actus/nightmare/154807100/nightmare-ch00042-r154807100.epub','2026-09-20T02:44:15.154976862Z','materialized','@ROOT@/artifacts/actus/nightmare/154807100/nightmare-ch00042-r154807100.epub.metadata.json','@ROOT@/artifacts/actus/nightmare/154807100/nightmare-ch00042-r154807100.epub.normalized.json','@ROOT@/artifacts/actus/nightmare/154807100/nightmare-ch00042-r154807100.epub.raw.json');
CREATE TABLE leases (
  key TEXT PRIMARY KEY,
  holder TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE publish_records (
  id TEXT PRIMARY KEY,
  artifact_id TEXT NOT NULL,
  target_id TEXT NOT NULL,
  target_kind TEXT NOT NULL,
  target_ref TEXT NOT NULL,
  publish_hash TEXT NOT NULL,
  published_at TEXT NOT NULL,
  status TEXT NOT NULL,
  message TEXT NOT NULL,
  UNIQUE(artifact_id, target_id, publish_hash)
);
INSERT INTO "publish_records" VALUES('pub_9c1c99ea-4548-4992-868d-5257c1fac8d9','art_0ba37171-60a2-4b43-8ea1-efb155a9c437','library','filesystem','@ROOT@/library/actus/nightmare/nightmare-ch00042-r154807100.epub','f616d30f0207f0534505beafc8d538f31cd1f31e8f9e775be55830f48ed515f3','2026-09-20T02:44:15.164252916Z','published','');
INSERT INTO "publish_records" VALUES('pub_1f66acef-3f03-4646-90f3-14c1c96fc5ef','art_76477aad-0a1b-441a-99b6-88141eabc630','library','filesystem','@ROOT@/library/actus/nightmare/nightmare-ch00017-r154807035.epub','9e6b469debc4bf8452d6cf839d5112c50d20ac57932dc1e2505715de2ae6fe9d','2026-09-20T02:44:15.165850168Z','published','');
CREATE TABLE release_assignments (
  release_id TEXT PRIMARY KEY,
  track_id TEXT NOT NULL,
  rule_id TEXT NOT NULL,
  release_role TEXT NOT NULL,
  confidence REAL NOT NULL
);
INSERT INTO "release_assignments" VALUES('rel_aefdb067-45a9-48f8-819c-5dab0b05f2e6','trk_10798eed-e63a-4df7-aa86-da104e9e430a','actus/rule/nightmare/title_regex/0','chapter',1.0);
INSERT INTO "release_assignments" VALUES('rel_63bc36b1-40ba-4ab1-8bc3-c70e73c87e62','trk_421f74d8-b883-4d52-9262-b8b9a4b30c86','fallback/actus/unmatched','unknown',1.0);
INSERT INTO "release_assignments" VALUES('rel_2034feca-b809-4267-8a30-38756c8723a7','trk_10798eed-e63a-4df7-aa86-da104e9e430a','actus/rule/nightmare/title_regex/0','chapter',1.0);
CREATE TABLE releases (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL,
  provider_release_id TEXT NOT NULL,
  url TEXT NOT NULL,
  title TEXT NOT NULL,
  published_at TEXT NOT NULL,
  edited_at TEXT NOT NULL,
  post_type TEXT NOT NULL,
  visibility_state TEXT NOT NULL,
  normalized_payload_ref TEXT NOT NULL,
  raw_payload_ref TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  discovered_at TEXT NOT NULL,
  status TEXT NOT NULL,
  UNIQUE(source_id, provider_release_id)
);
INSERT INTO "releases" VALUES('rel_aefdb067-45a9-48f8-819c-5dab0b05f2e6','actus','154807035','https://www.patreon.com/posts/nightmare-realm-summoner-17-154807035','Nightmare Realm Summoner - Chapter 17','2026-04-03T22:30:00Z','2026-04-03T22:31:00Z','text_only','visible','@ROOT@/artifacts/actus/nightmare/154807035/release.normalized.json','@ROOT@/artifacts/actus/nightmare/154807035/release.raw.json','62b0389ac950362959c552dca85c51c0acb0b80cc3b838c4da9dca1895281fc0','2026-09-20T02:44:11.716096273Z','discovered');
INSERT INTO "releases" VALUES('rel_63bc36b1-40ba-4ab1-8bc3-c70e73c87e62','actus','154807101','https://www.patreon.com/posts/schedule-update-154807101','Schedule Update','2026-04-03T12:00:00Z','2026-04-03T12:10:00Z','text_only','visible','@ROOT@/artifacts/actus/unmatched/154807101/release.normalized.json','@ROOT@/artifacts/actus/unmatched/154807101/release.raw.json','55a373e861e11bf33b85ab55db67510840f81ab8ea5ca77d178600884ca0a112','2026-09-20T02:44:13.461541726Z','discovered');
INSERT INTO "releases" VALUES('rel_2034feca-b809-4267-8a30-38756c8723a7','actus','154807100','https://www.patreon.com/posts/nightmare-realm-154807100','Nightmare Realm Summoner - Chapter 42','2026-04-03T09:30:00Z','2026-04-03T09:45:00Z','text_only','visible','@ROOT@/artifacts/actus/nightmare/154807100/release.normalized.json','@ROOT@/artifacts/actus/nightmare/154807100/release.raw.json','480756de9d8187b072a7219a3505f31c2d8d328e93a04a56538e485a3260e3db','2026-09-20T02:44:13.463228395Z','discovered');
CREATE TABLE run_records (
  id TEXT PRIMARY KEY,
  command TEXT NOT NULL,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  status TEXT NOT NULL,
  summary TEXT NOT NULL,
  source_scope TEXT NOT NULL,
  dry_run INTEGER NOT NULL
);
INSERT INTO "run_records" VALUES('run_a8ad6b9e-953c-438f-a2b6-f3d298857e1b','run sync','2026-09-20T02:44:11.713566853Z','2026-09-20T02:44:15.160440869Z','succeeded','discovered=3 changed=3 unchanged=0 materialized=2','',0);
INSERT INTO "run_records" VALUES('run_4a41d375-67fe-43de-b166-5c3b77337c0a','run publish','2026-09-20T02:44:15.16136112Z','2026-09-20T02:44:15.166737335Z','succeeded','published=2 skipped=0 failed=0','',0);
CREATE TABLE sources (
  id TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  source_url TEXT NOT NULL,
  source_type TEXT NOT NULL,
  creator_id TEXT NOT NULL,
  creator_name TEXT NOT NULL,
  auth_profile_id TEXT NOT NULL,
  enabled INTEGER NOT NULL,
  sync_cursor TEXT NOT NULL,
  last_synced_at TEXT NOT NULL
);
INSERT INTO "sources" VALUES('actus','patreon','https://www.patreon.com/c/Actus/posts','creator_feed','2002','Actus','fixture',1,'{"version":1,"lookback":25,"recent_release_ids":["154807035","154807101","154807100"]}','2026-09-20T02:44:15.157320281Z');
CREATE TABLE story_tracks (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL,
  track_key TEXT NOT NULL,
  track_name TEXT NOT NULL,
  canonical_author TEXT NOT NULL,
  series_meta TEXT NOT NULL,
  output_policy TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(source_id, track_key)
);
INSERT INTO "story_tracks" VALUES('trk_10798eed-e63a-4df7-aa86-da104e9e430a','actus','nightmare','Nightmare','Actus','{"canonical_author":"Actus","content_strategy":"text_post","output_format":"epub","preface_mode":"none","series_id":"nightmare"}','epub','2026-09-20T02:44:11.716096107Z','2026-09-20T02:44:13.463228354Z');
INSERT INTO "story_tracks" VALUES('trk_421f74d8-b883-4d52-9262-b8b9a4b30c86','actus','unmatched','Unmatched','Actus','{"content_strategy":"manual","output_format":"preserve","preface_mode":"none","series_id":"unmatched"}','preserve','2026-09-20T02:44:13.461541643Z','2026-09-20T02:44:13.461541685Z');
COMMIT;