BEGIN TRANSACTION;
CREATE TABLE artifacts (
  id TEXT PRIMARY KEY,
  release_id TEXT NOT NULL,
  track_id TEXT NOT NULL,
  artifact_kind TEXT NOT NULL,
  is_canonical INTEGER NOT NULL,
  filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  storage_ref TEXT NOT NULL,
  built_at TEXT NOT NULL,
  state TEXT NOT NULL,
  metadata_ref TEXT NOT NULL,
  normalized_ref TEXT NOT NULL,
  raw_ref TEXT NOT NULL,
  UNIQUE(release_id, sha256, artifact_kind)
);
INSERT INTO "artifacts" VALUES('art_a57b0ae6-bef1-4a11-b17c-09eeea0ad1b6','rel_e102eb8c-6d40-4be7-905b-0e9836710abe','trk_2addace3-dbf3-4c0c-bb6a-f3a5451b01f8','html',1,'nightmare-ch00017-r154807035.html','text/html','6041f6ae168eaa8ef08006d2ca811de8d4169a0e0073481d0d008062896154e4','@ROOT@/artifacts/actus/nightmare/154807035/nightmare-ch00017-r154807035.html','2026-09-20T01:52:28.084026167Z','materialized','@ROOT@/artifacts/actus/nightmare/154807035/nightmare-ch00017-r154807035.html.metadata.json','@ROOT@/artifacts/actus/nightmare/154807035/nightmare-ch00017-r154807035.html.normalized.json','@ROOT@/artifacts/actus/nightmare/154807035/nightmare-ch00017-r154807035.html.raw.json');
INSERT INTO "artifacts" VALUES('art_a0cfe497-939e-46dd-9b1b-7947d3b9081a','rel_948b6bef-983f-4260-bf4b-67c2b32fbcb9','trk_2addace3-dbf3-4c0c-bb6a-f3a5451b01f8','html',1,'nightmare-ch00042-r154807100.html','text/html','7d47633b8a8be34688631ab88290d1fe8fa1c952229179005ea62e04e8419f27','@ROOT@/artifacts/actus/nightmare/154807100/nightmare-ch00042-r154807100.html','2026-09-20T01:52:28.090378329Z','materialized','@ROOT@/artifacts/actus/nightmare/154807100/nightmare-ch00042-r154807100.html.metadata.json','@ROOT@/artifacts/actus/nightmare/154807100/nightmare-ch00042-r154807100.html.normalized.json','@ROOT@/artifacts/actus/nightmare/154807100/nightmare-ch00042-r154807100.html.raw.json');
CREATE TABLE leases (
  key TEXT PRIMARY KEY,
  holder TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE publish_records (
  id TEXT PRIMARY KEY,
  artifact_id TEXT NOT NULL,
  target_id TEXT NOT NULL,
  target_kind TEXT NOT NULL,
  target_ref TEXT NOT NULL,
  publish_hash TEXT NOT NULL,
  published_at TEXT NOT NULL,
  status TEXT NOT NULL,
  message TEXT NOT NULL,
  UNIQUE(artifact_id, target_id, publish_hash)
);
INSERT INTO "publish_records" VALUES('pub_750f1920-cd05-49f0-aa9e-dc907cc6a37d','art_a0cfe497-939e-46dd-9b1b-7947d3b9081a','library','filesystem','@ROOT@/library/actus/nightmare/nightmare-ch00042-r154807100.html','ee9bdce7cd0af9973ce756b7c0731d0d8ee1cd36a421e9588ebedd674fe2644c','2026-09-20T01:52:28.095427067Z','published','');
INSERT INTO "publish_records" VALUES('pub_1be880a7-ed1c-46ae-8377-25e1fa2b5c36','art_a57b0ae6-bef1-4a11-b17c-09eeea0ad1b6','library','filesystem','@ROOT@/library/actus/nightmare/nightmare-ch00017-r154807035.html','6d0852d5f650dcbd3830b1944cb9289c32b1fa35b54446cc622fc313303a680a','2026-09-20T01:52:28.096927201Z','published','');
CREATE TABLE release_assignments (
  release_id TEXT PRIMARY KEY,
  track_id TEXT NOT NULL,
  rule_id TEXT NOT NULL,
  release_role TEXT NOT NULL,
  confidence REAL NOT NULL
);
INSERT INTO "release_assignments" VALUES('rel_e102eb8c-6d40-4be7-905b-0e9836710abe','trk_2addace3-dbf3-4c0c-bb6a-f3a5451b01f8','actus/rule/nightmare/title_regex/0','chapter',1.0);
INSERT INTO "release_assignments" VALUES('rel_5e461929-9809-4fdb-8e9b-4737033bdfe5','trk_330d87b6-05e2-43b4-b283-4d1ee26db502','fallback/actus/unmatched','unknown',1.0);
INSERT INTO "release_assignments" VALUES('rel_948b6bef-983f-4260-bf4b-67c2b32fbcb9','trk_2addace3-dbf3-4c0c-bb6a-f3a5451b01f8','actus/rule/nightmare/title_regex/0','chapter',1.0);
CREATE TABLE releases (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL,
  provider_release_id TEXT NOT NULL,
  url TEXT NOT NULL,
  title TEXT NOT NULL,
  published_at TEXT NOT NULL,
  edited_at TEXT NOT NULL,
  post_type TEXT NOT NULL,
  visibility_state TEXT NOT NULL,
  normalized_payload_ref TEXT NOT NULL,
  raw_payload_ref TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  discovered_at TEXT NOT NULL,
  status TEXT NOT NULL,
  UNIQUE(source_id, provider_release_id)
);
INSERT INTO "releases" VALUES('rel_e102eb8c-6d40-4be7-905b-0e9836710abe','actus','154807035','https://www.patreon.com/posts/nightmare-realm-summoner-17-154807035','Nightmare Realm Summoner - Chapter 17','2026-04-03T22:30:00Z','2026-04-03T22:31:00Z','text_only','visible','@ROOT@/artifacts/actus/nightmare/154807035/release.normalized.json','@ROOT@/artifacts/actus/nightmare/154807035/release.raw.json','62b0389ac950362959c552dca85c51c0acb0b80cc3b838c4da9dca1895281fc0','2026-09-20T01:52:28.083105037Z','discovered');
INSERT INTO "releases" VALUES('rel_5e461929-9809-4fdb-8e9b-4737033bdfe5','actus','154807101','https://www.patreon.com/posts/schedule-update-154807101','Schedule Update','2026-04-03T12:00:00Z','2026-04-03T12:10:00Z','text_only','visible','@ROOT@/artifacts/actus/unmatched/154807101/release.normalized.json','@ROOT@/artifacts/actus/unmatched/154807101/release.raw.json','55a373e861e11bf33b85ab55db67510840f81ab8ea5ca77d178600884ca0a112','2026-09-20T01:52:28.086203096Z','discovered');
INSERT INTO "releases" VALUES('rel_948b6bef-983f-4260-bf4b-67c2b32fbcb9','actus','154807100','https://www.patreon.com/posts/nightmare-realm-154807100','Nightmare Realm Summoner - Chapter 42','2026-04-03T09:30:00Z','2026-04-03T09:45:00Z','text_only','visible','@ROOT@/artifacts/actus/nightmare/154807100/release.normalized.json','@ROOT@/artifacts/actus/nightmare/154807100/release.raw.json','480756de9d8187b072a7219a3505f31c2d8d328e93a04a56538e485a3260e3db','2026-09-20T01:52:28.088775028Z','discovered');
CREATE TABLE run_records (
  id TEXT PRIMARY KEY,
  command TEXT NOT NULL,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  status TEXT NOT NULL,
  summary TEXT NOT NULL,
  source_scope TEXT NOT NULL,
  dry_run INTEGER NOT NULL
);
INSERT INTO "run_records" VALUES('run_e71b74f8-783e-4d4a-befc-49715de93e34','run sync','2026-09-20T01:52:28.078506302Z','2026-09-20T01:52:28.092682218Z','succeeded','discovered=3 changed=3 unchanged=0 materialized=2','',0);
INSERT INTO "run_records" VALUES('run_d7c91cd4-5934-4fcd-b0ed-aafe8350048e','run publish','2026-09-20T01:52:28.093243137Z','2026-09-20T01:52:28.097959832Z','succeeded','published=2 skipped=0 failed=0','',0);
CREATE TABLE sources (
  id TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  source_url TEXT NOT NULL,
  source_type TEXT NOT NULL,
  creator_id TEXT NOT NULL,
  creator_name TEXT NOT NULL,
  auth_profile_id TEXT NOT NULL,
  enabled INTEGER NOT NULL,
  sync_cursor TEXT NOT NULL,
  last_synced_at TEXT NOT NULL
);
INSERT INTO "sources" VALUES('actus','patreon','https://www.patreon.com/c/Actus/posts','creator_feed','2002','Actus','fixture',1,'{"version":1,"lookback":25,"recent_release_ids":["154807035","154807101","154807100"]}','2026-09-20T01:52:28.091859421Z');
CREATE TABLE story_tracks (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL,
  track_key TEXT NOT NULL,
  track_name TEXT NOT NULL,
  canonical_author TEXT NOT NULL,
  series_meta TEXT NOT NULL,
  output_policy TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(source_id, track_key)
);
INSERT INTO "story_tracks" VALUES('trk_2addace3-dbf3-4c0c-bb6a-f3a5451b01f8','actus','nightmare','Nightmare','Actus','{"canonical_author":"Actus","content_strategy":"text_post","output_format":"preserve","preface_mode":"none","series_id":"nightmare"}','preserve','2026-09-20T01:52:28.083104787Z','2026-09-20T01:52:28.088774986Z');
INSERT INTO "story_tracks" VALUES('trk_330d87b6-05e2-43b4-b283-4d1ee26db502','actus','unmatched','Unmatched','Actus','{"content_strategy":"manual","output_format":"preserve","preface_mode":"none","series_id":"unmatched"}','preserve','2026-09-20T01:52:28.086202971Z','2026-09-20T01:52:28.086203013Z');
COMMIT;